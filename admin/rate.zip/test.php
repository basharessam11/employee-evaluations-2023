<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
 <script src="jQuery/jquery-2.2.4.min.js"></script>

<script type="text/javascript">
	
	$.ajax({
		url: 'https://qaymni.com/_changeResultsIndex.php',
		type: 'POST',
		
		data: {index: -1},
	})
	.done(function() {
		console.log("success");
	})
	.fail(function() {
		console.log("error");
	})
	.always(function() {
		console.log("complete");
	});
	
</script>
</body>
</html>