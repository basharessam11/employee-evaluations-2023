<?php
echo 1;


?>